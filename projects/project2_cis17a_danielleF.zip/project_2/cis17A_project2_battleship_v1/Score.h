/* 
 * File:   Score.h
 * Author: DanYell
 * Created: 12-07-2022 @ 7:18 PM
 */

#ifndef SCORE_H
#define SCORE_H

struct Score {
//class Score {
//private:
    int nPlayrs;
    int maxGmes;
    int ttlGams;
    int ttlRnds;
    Player *player;
    //Choices *choices;
};

#endif /* SCORE_H */

