/* 
 * File:   Choices.h
 * Author: Danielle Fernandez
 * Created on November 2, 2022, 9:02 PM
 */

#ifndef CHOICES_H
#define CHOICES_H

struct Choices {
    int  size;
    char *arr; //CHANGE TO ARRAY
    int  *indx;//Index used in sorting the array
};

#endif /* CHOICES_H */

