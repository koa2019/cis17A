// #include <string>
#include "RetailItem.h"
using namespace std;

// Class constructor
RetailItem::RetailItem(string n, int u, float p){
    name=n;
    numUnits=u;
    price=p;
}