/* 
 * File:   Primes.h
* Author: Danielle Fernandez
 * Created on October 24, 2022, 8:19 PM
 */

#ifndef PRIMES_H
#define PRIMES_H

// prb 7
// single structure that holds a prime number that's divisible into # 
// and how  many times it does
struct Primes {
    int p;
    int power;
};

#endif /* PRIMES_H */

